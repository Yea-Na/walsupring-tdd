package com.walsupring.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.walsupring.controller.dto.user.UserChangeNicknameDto;
import com.walsupring.controller.dto.user.UserJoinDto;
import com.walsupring.user.domain.User;
import com.walsupring.user.domain.UserRepository;
import com.walsupring.user.domain.UserStatus;
import com.walsupring.user.service.UserService;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;
import java.util.Optional;

import static org.springframework.boot.test.context.SpringBootTest.WebEnvironment.RANDOM_PORT;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest(webEnvironment = RANDOM_PORT)
@AutoConfigureMockMvc
@Transactional
class UserControllerTest {
    @Autowired
    private MockMvc mockMvc;  // 실제 요청 날릴 객체

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private UserController userController;



    @Test
    void 회원가입_성공() throws Exception {
        UserJoinDto.Request request = new UserJoinDto.Request("loginId","123","이름","별명");

        mockMvc.perform(MockMvcRequestBuilders.post("/users")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsBytes(request)))
                .andDo(MockMvcResultHandlers.print());

        Optional<User> optionalUser = userRepository.findByLoginId("loginId");

        Assertions.assertThat(optionalUser.isPresent()).isTrue();
    }


    @Test
    void 유저_리스트_조회_성공() throws Exception {
        User user1 = userRepository.save(new User("loginId1", "password1", "name1","nickname1"));
        User user2 = userRepository.save(new User("loginId2", "password2", "name2","nickname2"));

        mockMvc.perform(MockMvcRequestBuilders.get("/users"))
                .andDo(MockMvcResultHandlers.print())
                .andExpectAll(유저_리스트_검증(0,user1))
                .andExpectAll(유저_리스트_검증(1,user2));
    }



    @Test
    void 유저_단건_조회_성공() throws Exception {
        User user = userRepository.save(new User("loginId", "password", "name","nickname"));
        mockMvc.perform(MockMvcRequestBuilders.get("/users/{id}",user.getId()))
                .andDo(MockMvcResultHandlers.print())
                .andExpectAll(jsonPath("$.id").value(1),
                        jsonPath("$.loginId").value("loginId"),
                        jsonPath("$.name").value("name"),
                        jsonPath("$.nickname").value("nickname"),
                        jsonPath("$.status").value(UserStatus.ACTIVATED.name()),
                        jsonPath("$.createdAt").isNotEmpty(),
                        jsonPath("$.updatedAt").isEmpty()
                        );  //json 검증



    }

    @Test
    void 닉네임_변경_성공() throws Exception {
        UserChangeNicknameDto.Request request = new UserChangeNicknameDto.Request("newNickname");
        User user = userRepository.save(new User("loginId", "password", "name","nickname"));
        mockMvc.perform(MockMvcRequestBuilders.patch("/users/{id}/change-nickname",user.getId())
                .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsBytes(request)))
                .andDo(MockMvcResultHandlers.print())
                .andExpectAll(jsonPath("$.id").value(1),
                        jsonPath("$.loginId").value("loginId"),
                        jsonPath("$.name").value("name"),
                        jsonPath("$.nickname").value("newNickname"),
                        jsonPath("$.status").value(UserStatus.ACTIVATED.name()),
                        jsonPath("$.createdAt").isNotEmpty(),
                        jsonPath("$.updatedAt").isEmpty()

                );

    }

    @Test
    void 패스워드_변경_성공() throws Exception {


    }

    private ResultMatcher[] 유저_리스트_검증(int index, User user) {  //
        return List.of(
                jsonPath("$.[" + index + "].id").value(user.getId()),
                jsonPath("$.[" + index + "].loginId").value(user.getLoginId()),
                jsonPath("$.[" + index + "].name").value(user.getName()),
                jsonPath("$.[" + index + "].nickname").value(user.getNickname()),
                jsonPath("$.[" + index + "].status").value(user.getStatus().name()),
                jsonPath("$.[" + index + "].createdAt").isNotEmpty(),
                jsonPath("$.[" + index + "].updatedAt").isEmpty())
                .toArray(ResultMatcher[]::new);

    }






}

