package com.walsupring.gallery.domain;

public enum GalleryStatus {
    PUBLIC, //0
    PRIVATE, //1..
    DELETED,
}
