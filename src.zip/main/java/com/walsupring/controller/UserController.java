package com.walsupring.controller;

import com.walsupring.controller.dto.user.GetUserDto;
import com.walsupring.controller.dto.user.GetUsersDto;
import com.walsupring.controller.dto.user.UserChangeNicknameDto;
import com.walsupring.controller.dto.user.UserJoinDto;
import com.walsupring.user.domain.User;
import com.walsupring.user.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

//@Controller
//@ResponseBody
//통합버전 ->
@RestController  // @Controller + ResponseBody
@RequestMapping("/users")  // prefix처럼 붙음
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;

    @PostMapping
    public void join(@RequestBody UserJoinDto.Request request) {
        //회원가입
        userService.join(request.getLoginId(), request.getPassword(), request.getName(), request.getNickname());
    }


    @GetMapping
    public List<GetUsersDto.Response> getUsers() {
        //유저 리스트 반환
        List<User> users = userService.getUsers();
//
//        List<GetUsersDto.Response> responses = new ArrayList<>();
//
//        for (User user: users) {
//            responses.add(new GetUsersDto.Response(user));
//        }
        List<GetUsersDto.Response> responses = users.stream().map(GetUsersDto.Response::new).toList();

        //map  //예제 10개
        //filter
        //flatMap

        return responses;
    }

    @GetMapping("/{id}")
    public GetUserDto.Response getUser(@PathVariable Long id){
        //유저 단건 조회
        //생성자를 통한 방식 -> 선호
        //빌더를 통한 방식 -> nullsafe하지 않음 -> 선호 x
        User user = userService.getUser(id);

        return new GetUserDto.Response(user);
    }

    @PatchMapping("/{id}/change-nickname")
    public UserChangeNicknameDto.Response changeNickname(@PathVariable Long id, @RequestBody UserChangeNicknameDto.Request request) {
        //유저 닉네임 변경
        User user = userService.changeNickname(id, request.getNickname());

        return new UserChangeNicknameDto.Response(user);

    }

    @PatchMapping("/{id}/change-password")
    public UserChangeNicknameDto.Response changePassword(@PathVariable Long id, @RequestBody UserChangeNicknameDto.Request request) {
        //패스워드 변경
        User user = userService.changePassword(id, request.getNickname());
        return new UserChangeNicknameDto.Response(user);
    }
}
