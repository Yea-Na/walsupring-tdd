package com.walsupring.controller.dto.user;

import com.walsupring.user.domain.UserStatus;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

public class UserChangePasswordDto {

    @Getter
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Request {
        private String nickname;
    }

    @Getter
    @NoArgsConstructor
    public static class Response {
        private Long id;
        private String loginId;
        private String name;
        private String nickname;
        private UserStatus status;


    }



}
