package com.walsupring.user.domain;

public enum UserStatus {
    ACTIVATED,
    INACTIVATED
}
